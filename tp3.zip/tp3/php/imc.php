<?php
class IMC
{
    public function calcularIMC(int $peso, int $altura): float
    {
        $alturaMetros = $altura / 100;
        return $peso / ($alturaMetros * $alturaMetros);
    }

    public function obtenerEstadoIMC(float $imc): string
    {
        if ($imc < 15.0) {
            $estado = 'Delgadez muy severa';
        } elseif ($imc >= 15.0 && $imc <= 15.9) {
            $estado = 'Delgadez severa';
        } elseif ($imc >= 16.0 && $imc <= 18.4) {
            $estado = 'Delgadez'; 
        } elseif ($imc >= 18.5 && $imc <= 24.9) {
            $estado = 'Normal'; 
        } elseif ($imc >= 25.0 && $imc <= 29.9) {
            $estado = 'Sobrepeso';
        } elseif ($imc >= 30.0 && $imc <= 34.9) {
            $estado = 'Obesidad moderada';
        } elseif($imc>=35.0 && $imc<=39.9){
            $estado = 'Obesidad severa';
        }elseif($imc>=40.0){
            $estado= 'Obesidad morbida';
        }
        return $estado;
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST'){
    if (isset($_POST['peso']) && isset($_POST['altura'])) {
        $peso = (int) $_POST['peso'];
        $altura = (int) $_POST['altura'];

        $imcCalculator = new IMC();
        $imc = $imcCalculator->calcularIMC($peso, $altura);
        $estado = $imcCalculator->obtenerEstadoIMC($imc);
    
        if (isset($imc) && isset($estado)) {
            echo "Tu IMC es: " . round($imc, 2) . "<br>";
            echo "Estado: " . $estado . "<br>";
        }
    }
}

?>