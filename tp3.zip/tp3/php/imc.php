<?php
function calcularIMC(int $peso, int $altura): float
{
    $alturaMetros = $altura / 100;
    return $peso / ($alturaMetros * $alturaMetros);
}

function obtenerEstadoIMC(float $imc): string
{
    if ($imc < 18.5) {
        return 'Delgadez';
    } elseif ($imc >= 18.5 && $imc <= 24.9) {
        return 'Normal';
    } elseif ($imc >= 25 && $imc <= 29.9) {
        return 'Sobrepeso';
    } else {
        return 'Obesidad';
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $peso = $_POST['peso'];
    $altura = $_POST['altura'];

    $imc = calcularIMC((int) $peso, (int) $altura);


    $estado = obtenerEstadoIMC($imc);

}

if (isset($imc) && isset($estado)) {
    echo "Tu IMC es: " . round($imc, 2) . "<br>";
    echo "Estado: " . $estado . "<br>";
}
?>