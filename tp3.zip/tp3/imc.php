<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de IMC</title>
    <!-- http://localhost/objetos/TP3/imc.php -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>

<body>
    <div class="container mt-5">
        <h1 class="text-center text-primary mb-4">Calculadora de IMC</h1>


        <form method="POST" action="">
            <div class="mb-3 row">
                <label for="peso" class="col-sm-3 col-form-label text-primary">Peso (kg)</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control text-primary" id="peso" name="peso" required>
                </div>
            </div>
            <div class="mb-3 row">
                <label for="altura" class="col-sm-3 col-form-label text-primary">Altura (cm)</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control text-primary" id="altura" name="altura" required>
                </div>
            </div>
            <div class="mb-3 row">
                <div class="col-sm-12 text-center">
                    <button class="btn btn-primary" type="submit">Calcular IMC</button>
                </div>
            </div>
        </form>
        <div id="resultados" class="mt-4 text-center text-primary">
            <?php
            include_once "php/imc.php";

            ?>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>