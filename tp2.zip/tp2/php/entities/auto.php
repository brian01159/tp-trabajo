<?php
require_once "../entities/vehiculo.php";
require_once "../interfaces/i.concesionaria.php";
require_once "../entities/concesionaria.php";
class Auto extends vehiculo
{
    private $puertas;
    public function __construct(string $marca, string $modelo, float $precio, int $puertas)
    {

        parent::__construct($marca, $modelo, $precio);
        $this->puertas = $puertas;
    }
    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }

    }


    public function __set($property, $value)
    {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
    }

    public function __toString()
    {
        return "Marca:" . $this->__get("marca") . "// Modelo:" . $this->__get("modelo") . "// Puertas:" . $this->__get("puertas") . "// Precio: $" . number_format($this->__get("precio"), 2, ',', '.');
    }
}

?>