<?php
require_once "../entities/auto.php";
require_once "../interfaces/i.concesionaria.php";
require_once "../entities/moto.php";
require_once "../entities/vehiculos.php";
class Concesionaria
{

    private array $vehiculos = [];

    public function __construct(array $vehiculos = [])
    {

        $this->vehiculos = $vehiculos;
    }



    public function agregarVehiculo(Vehiculo $vehiculos): void
    {
        $this->vehiculos[] = $vehiculos;
    }



    public function obtenerMayoroMenor(): void
    {
        usort(
            $this->vehiculos,
            fn($vehiculo1, $vehiculo2) =>
            $vehiculo2->__get("precio") <=> $vehiculo1->__get("precio")
        );
        foreach ($this->vehiculos as $vehiculo) {
            echo $vehiculo->__get("marca") . " " . $vehiculo->__get("modelo") . "<br>";
        }
    }


    public function obtenerOrdenNatural(): void
    {
        usort(
            $this->vehiculos,
            fn($vehiculo1, $vehiculo2) =>
            [$vehiculo1->__get("marca"), $vehiculo1->__get("modelo"), $vehiculo1->__get("precio")] <=>
            [$vehiculo2->__get("marca"), $vehiculo2->__get("modelo"), $vehiculo2->__get("precio")]
        );

        foreach ($this->vehiculos as $vehiculo) {
            echo $vehiculo . "<br>";
        }

    }

    public function obtenerMasCaro()
    {
        $masCaro = $this->vehiculos[0];
        foreach ($this->vehiculos as $vehiculo) {
            $masCaro = ($vehiculo->__get("precio") > $masCaro->__get("precio")) ? $vehiculo : $masCaro;
        }
        return $masCaro;

    }

    public function obtenerMasBarato()
    {
        $masBarato = $this->vehiculos[0];
        foreach ($this->vehiculos as $vehiculo) {
            $masBarato = ($vehiculo->__get("precio") < $masBarato->__get("precio")) ? $vehiculo : $masBarato;
        }
        return $masBarato;

    }
    public function obtenerVehiculoY()
    {
        $vehiculosConLetraY = array_filter($this->vehiculos, fn($vehiculo) => str_contains($vehiculo->__get("modelo"), 'Y'));
        foreach ($vehiculosConLetraY as $vehiculo) {
            echo $vehiculo->__get("marca") . "," . $vehiculo->__get("modelo") . "," . number_format($vehiculo->__get("precio"), 2, ',', '.') . "<br>";
        }
    }
    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }

    }


    public function __set($property, $value)
    {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
    }
   
}

?>