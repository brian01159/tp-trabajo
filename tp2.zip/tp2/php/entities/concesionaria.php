<?php
require_once "../entities/auto.php";
require_once "../interfaces/i.concesionaria.php";
require_once "../entities/moto.php";
require_once "../entities/vehiculos.php";
class Concesionaria
{

    private array $vehiculos = [];

    public function __construct(array $vehiculos = [])
    {

        $this->vehiculos = $vehiculos;
    }



    public function agregarVehiculo(Vehiculo $vehiculos): void
    {
        $this->vehiculos[] = $vehiculos;
    }



    public function obtenerMayoroMenor(): void
    {
        usort(
            $this->vehiculos,
            fn($vehiculo1, $vehiculo2) =>
            $vehiculo2->__get("precio") <=> $vehiculo1->__get("precio")
        );
        foreach ($this->vehiculos as $vehiculo) {
            echo $vehiculo->__get("marca") . " " . $vehiculo->__get("modelo") . "<br>";
        }
    }


    public function obtenerOrdenNatural(): void
    {
        usort(
            $this->vehiculos,
            fn($vehiculo1, $vehiculo2) =>
            [$vehiculo1->__get("marca"), $vehiculo1->__get("modelo"), $vehiculo1->__get("precio")] <=>
            [$vehiculo2->__get("marca"), $vehiculo2->__get("modelo"), $vehiculo2->__get("precio")]
        );

        foreach ($this->vehiculos as $vehiculo) {
            echo $vehiculo . "<br>";
        }

    }
    public function obtenerMasCaro(): void
    {
        usort($this->vehiculos, fn($vehiculo1, $vehiculo2) => $vehiculo2->__get('precio') <=> $vehiculo1->__get('precio'));
        $caro = $this->vehiculos[0];
        echo "Vehículo más caro: " . $caro->__get('marca') . " " . $caro->__get('modelo') . "<br>";
    }

    public function obtenerMasBarato(): void
    {
        usort($this->vehiculos, fn($vehiculo1, $vehiculo2) => $vehiculo1->__get('precio') <=> $vehiculo2->__get('precio'));
        $barato = $this->vehiculos[0];
        echo "Vehículo más barato: " . $barato->__get('marca') . " " . $barato->__get('modelo') . "<br>";
    }


    public function obtenerVehiculoY(): void
    {
        foreach ($this->vehiculos as $vehiculo) {
            if (stripos($vehiculo->modelo, 'Y') !== false) {
                echo "Vehículo que contiene en el modelo la letra Y: " . $vehiculo->__get("marca") . " " . $vehiculo->__get("modelo") . " $" . number_format($vehiculo->__get("precio"), 2, ',', '.') . "<br>";
            }
        }
    }
    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }

    }
}

?>