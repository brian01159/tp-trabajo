<?php
require_once "../entities/vehiculos.php";
require_once "../interfaces/i.concesionaria.php";
require_once "../entities/concesionaria.php";
class Moto extends vehiculo
{
    private $cilindradas;
    public function __construct(string $marca, string $modelo, float $precio, int $cilindradas)
    {

        parent::__construct($marca, $modelo, $precio);
        $this->cilindradas = $cilindradas;
    }
    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }

    }


    public function __set($property, $value)
    {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
    }

    public function __toString()
    {
        return "Marca:" . $this->__get("marca") . "//" . "Modelo:" . $this->__get("modelo") . " //Cilindrada:" . $this->__Get("cilindradas") . "//Precio: $" . number_format($this->__get("precio"), 2, ',', '.');
    }
}

?>