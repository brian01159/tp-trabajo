<?php
require_once "../entities/concesionaria.php";
require_once "../interfaces/i.concesionaria.php";


abstract class Vehiculo
{
    private $marca;
    private $modelo;
    private $precio;

    public function __construct(string $marca, string $modelo, float $precio)
    {
        $this->marca = $marca;
        $this->modelo = $modelo;
        $this->precio = $precio;
    }



    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }

    }


    public function __set($property, $value)
    {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
    }

    public function __toString()
    {
        return "Marca:" . $this->__get("marca") . "// Modelo:" . $this->__get("modelo") . "// Precio: $" . number_format($this->__get("precio"), 2, ',', '.');
    }
}
?>