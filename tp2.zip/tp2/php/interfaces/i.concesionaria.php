<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
interface i_concesionaria
{





    public function agregarVehiculos(Vehiculo $vehiculo): void;




    public function obtenerMayoroMenor(): void;



    public function obtenerOrdenNatural(): void;



    public function obtenerMasCaro(): vehiculo;


    public function obtenerMasBarato(): vehiculo;


    public function obtenerVehiculoY(): void;

}







?>