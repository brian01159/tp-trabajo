<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculos.php";
interface i_concesionaria
{





    public function agregarVehiculos(Vehiculo $vehiculo): void;




    public function obtenerMayoroMenor(): Vehiculo;



    public function obtenerOrdenNatural(): Vehiculo;



    public function obtenerMasCaro(): vehiculo;


    public function obtenerMasBarato(): Vehiculo;


    public function obtenerVehiculoY(): Vehiculo;

}







?>