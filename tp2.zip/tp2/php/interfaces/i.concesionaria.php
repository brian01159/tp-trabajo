<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculos.php";
interface i_concesionaria
{





    public function agregarVehiculos(Vehiculo $vehiculo): void;




    public function obtenerMayoroMenor(): void;



    public function obtenerOrdenNatural(): void;



    public function obtenerMasCaro(): void;


    public function obtenerMasBarato(): void;


    public function obtenerVehiculoY(): void;

}







?>