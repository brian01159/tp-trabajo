<?php ini_set('display_errors', 1) ?>
<?php
require_once "../entities/concesionaria.php";
require_once "../entities/auto.php";
require_once "../interfaces/i.concesionaria.php";
require_once "../entities/moto.php";
require_once "../entities/vehiculo.php";
//http://localhost/objetos/TP2/php/test/test_concesionaria.php
$concesionaria = new Concesionaria();
$vehiculo4 = new Auto("Peugeot", "208", 250000, 5);
$vehiculo3 = new Moto("Yamaha", "YBR", 80500.50, 160);
$vehiculo2 = new Moto("Honda", "Titan", 60000, 125);
$vehiculo1 = new Auto("Peugeot", "206", 200000, 4);
$concesionaria->agregarVehiculos($vehiculo1);
$concesionaria->agregarVehiculos($vehiculo2);
$concesionaria->agregarVehiculos($vehiculo3);
$concesionaria->agregarVehiculos($vehiculo4);
$concesionaria->mostrarVehiculos();
foreach ($concesionaria->__get("vehiculos") as $vehiculo) {

}
echo "=============================" . "<br>";
$vehiculoMasCaro = $concesionaria->obtenerMasCaro();
$vehiculoMasBarato = $concesionaria->obtenerMasBarato();
echo "Vehículo más caro: " . $vehiculoMasCaro->__get("marca") . " " . $vehiculoMasCaro->__get("modelo") . "<br>";
echo "vehiculo mas barato:" . $vehiculoMasBarato->__get("marca") . " " . $vehiculoMasBarato->__get("modelo") . "<br>";
echo "Vehículo que contiene en el modelo la letra Y:" . $concesionaria->obtenerVehiculoY() . "<br>";
echo "=============================" . "<br>";
echo "Vehículos ordenados por precio de mayor a menor:";
$concesionaria->obtenerMayoroMenor();
echo "=============================" . "<br>";
echo "Vehículos ordenados por orden natural (marca, modelo, precio):<br>";
$concesionaria->obtenerOrdenNatural();
?>