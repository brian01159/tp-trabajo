<?php ini_set('display_errors', 1) ?>
<?php
require_once "../entities/concesionaria.php";
require_once "../entities/auto.php";
require_once "../interfaces/i.concesionaria.php";
require_once "../entities/moto.php";
require_once "../entities/vehiculos.php";
//http://localhost/objetos/TP2/php/test/test_concesionaria.php
$concesionaria = new Concesionaria();
$vehiculo1 = new Auto("Peugeot", "208", 250000, 5);
$vehiculo2 = new Moto("Honda", "Titan", 60000, 125);
$vehiculo3 = new Auto("Peugeot", "206", 200000, 4);
$vehiculo4 = new Moto("Yamaha", "YBR", 80500.50, 160);
$concesionaria->agregarVehiculo($vehiculo1);
$concesionaria->agregarVehiculo($vehiculo2);
$concesionaria->agregarVehiculo($vehiculo3);
$concesionaria->agregarVehiculo($vehiculo4);
foreach ($concesionaria->__get("vehiculos") as $vehiculo) {
    echo $vehiculo . "<br>";
}
echo "=============================" . "<br>";
$concesionaria->obtenerMasCaro();
$concesionaria->obtenerMasBarato();
$concesionaria->obtenerVehiculoY();

echo "=============================" . "<br>";
echo "Vehículos ordenados por precio de mayor a menor:" . "<br>";
$concesionaria->obtenerMayoroMenor();
echo "=============================" . "<br>";
echo "Vehículos ordenados por orden natural (marca, modelo, precio):" . "<br>";
$concesionaria->obtenerOrdenNatural();

?>