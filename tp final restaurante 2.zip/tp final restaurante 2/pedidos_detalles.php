<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mantenimiento de Detalles de Pedidos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link rel="stylesheet" href="css/estilos.css">
</head>

<body>


    <?php include_once "menu.php"; ?>

    <div class="container my-5">

        <h1>Detalles de los Pedidos</h1>

        <form class="p-4 mb-4">
            <h3>Agregar Detalle de Pedido</h3>

            <div class="mb-3 row">
                <label for="pedido_id" class="col-sm-3 col-form-label form-label">Pedido ID</label>
                <div class="col-sm-9">
                <select id="pedido_id" name="pedido_id" class="form-select form-label"
                        aria-label="Default select example">
                        <?php include_once "php/front/select/pedidos_select.php"; ?>
                    </select>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="menu_id" class="col-sm-3 col-form-label form-label">Menu ID</label>
                <div class="col-sm-9">
                <select id="menu_id" name="menu_id" class="form-select form-label"
                        aria-label="Default select example">
                        <?php include_once "php/front/select/pedidos_detalles_select.php"; ?>
                    </select>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="cantidad" class="col-sm-3 col-form-label form-label">Cantidad</label>
                <div class="col-sm-9">
                    <input type="number" class="form-control" id="cantidad" name="cantidad" required>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="precio" class="col-sm-3 col-form-label form-label">Precio</label>
                <div class="col-sm-9">
                    <input type="number" step="0.01" class="form-control" id="precio" name="precio" required>
                </div>
            </div>

            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-success m-2 col-sm-4">Guardar Detalle</button>
                <button type="reset" class="btn btn-danger m-2 col-sm-4">Borrar</button>
            </div>

            <div class="mt-3">
                <label for="info" class="form-label">Información</label>
                <div class="form-control" id="info">
                    <?php include_once "php/front/agregar/agregar_pedidos_detalles.php"; ?>
                </div>
            </div>
        </form>

        <div class="category-section">
            <h2>Listado de Detalles de Pedidos</h2>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">ID Detalle</th>
                        <th scope="col">Pedido ID</th>
                        <th scope="col">Menu ID</th>
                        <th scope="col">Cantidad</th>
                        <th scope="col">Precio Unitario</th>
                        <th scope="col">Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php include_once "php/front/table/pedidos_detalles_table.php"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
        <script src="js/main.js"></script>
</body>

</html>