<!DOCTYPE html>
<html lang="es">
<!-- Menú de navegación -->
<?php include_once "menu.php"; ?>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalle del Pedido</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
</head>

<body>
    <div class="container my-4">
        <h2 class="text-center">Detalle del Pedido</h2>

        <!-- Información del Pedido -->
        <div class="card mb-3">
            <div class="card-header">Información del Pedido</div>
            <div class="card-body">
                <p><strong>Número de Pedido:</strong> #1</p>
                <p><strong>Fecha:</strong> 05/11/2024</p>
                <p><strong>Estado:</strong> <span class="badge badge-info">Preparación</span></p>
            </div>
        </div>

        <!-- Detalle de Productos -->
        <div class="card mb-3">
            <div class="card-header">Productos en el Pedido</div>
            <div class="card-body">
                <table class="table table-striped">
                    <thead>
                        <tr>
                            <th>Producto</th>
                            <th>Cantidad</th>
                            <th>Precio Unitario</th>
                            <th>Subtotal</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>Producto 1</td>
                            <td>1</td>
                            <td>$2550.00</td>
                            <td>$2550.00</td>
                        </tr>
                        <tr>
                            <td>Producto 2</td>
                            <td>1</td>
                            <td>$3600.00</td>
                            <td>$3600.00</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>

        <!-- Total del Pedido -->
        <div class="card mb-3">
            <div class="card-header">Resumen del Pedido</div>
            <div class="card-body">
                <p><strong>Subtotal:</strong> $6150.00</p>
                <p><strong>Impuestos:</strong> $615.00</p>
                <p><strong>Total:</strong> $6765.00</p>
            </div>
        </div>
    </div>
</body>

</html>