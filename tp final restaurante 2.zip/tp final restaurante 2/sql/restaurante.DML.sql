-- Active: 1730508914816@@127.0.0.1@3306
insert into menus (nombre, precio, categoria,activo) values
('Ensalada César', 2550.00, 'Entrante',TRUE),  
('Pizza Margarita', 3600.00, 'Principal',TRUE), 
('Tiramisú', 1650.00, 'Postre',TRUE),          
('Coca-Cola', 600.00, 'Bebida',TRUE),           
('Sopa de Lentejas', 1800.00, 'Entrante',TRUE), 
('Hamburguesa Clásica', 3000.00, 'Principal',TRUE), 
('Brownie', 1350.00, 'Postre',TRUE),            
('Agua Mineral', 450.00, 'Bebida',TRUE),        
('Pasta al Pesto', 3300.00, 'Principal',TRUE),  
('Batido de Frutas', 1050.00, 'Bebida',TRUE);   


insert into clientes (nombre, email, telefono, direccion,activo) values
('Juan Pérez', 'juan.perez@example.com', '123456789', 'Calle Falsa 123',TRUE),
('María López', 'maria.lopez@example.com', '987654321', 'Avenida Siempre Viva 742',TRUE),
('Carlos Gómez', 'carlos.gomez@example.com', '456123789', 'Calle Verdadera 456',TRUE),
('Ana Torres', 'ana.torres@example.com', '321654987', 'Paseo del Prado 789',TRUE),
('Lucía Martínez', 'lucia.martinez@example.com', '789456123', 'Calle de la Paz 101',TRUE),
('José Ramírez', 'jose.ramirez@example.com', '159753486', 'Calle Nueva 202',TRUE),
('Elena Sánchez', 'elena.sanchez@example.com', '753951852', 'Avenida Libertad 303',TRUE),
('Diego Romero', 'diego.romero@example.com', '951753486', 'Calle Principal 404',TRUE),
('Patricia Ruiz', 'patricia.ruiz@example.com', '456789123', 'Calle Secundaria 505',TRUE),
('Javier Díaz', 'javier.diaz@example.com', '147258369', 'Avenida Central 606',TRUE);


insert into pedidos (cliente_id, total, estado,activo) values
(1, 6000.00, 'Pendiente',TRUE),  
(2, 4650.00, 'En preparación',TRUE), 
(3, 9000.00, 'Entregado',TRUE),    
(4, 7500.00, 'Pendiente',TRUE),   
(5, 3600.00, 'Entregado',TRUE),   
(6, 5550.00, 'En preparación',TRUE), 
(7, 6600.00, 'Pendiente',TRUE),    
(8, 8100.00, 'Entregado',TRUE),     
(9, 4200.00, 'Pendiente',TRUE),     
(10, 4950.00, 'En preparación',TRUE); 


insert into pedidos_detalles (pedido_id, menu_id, cantidad, precio,activo) values
(1, 1, 1, 2550.00,TRUE), 
(1, 2, 1, 3600.00,TRUE),
(2, 3, 2, 1650.00,TRUE), 
(2, 4, 1, 600.00,TRUE), 
(3, 5, 1, 1800.00,TRUE), 
(3, 6, 2, 3000.00,TRUE), 
(4, 7, 3, 1350.00,TRUE), 
(4, 8, 2, 450.00,TRUE),  
(5, 9, 1, 3300.00,TRUE),  
(5, 10, 1, 1050.00,TRUE); 