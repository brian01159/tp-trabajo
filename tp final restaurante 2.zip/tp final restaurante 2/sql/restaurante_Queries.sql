-- Active: 1729293273636@@127.0.0.1@3306@restaurante
select * from menus;

select * from clientes;

select id, cliente_id, fecha, total, estado from pedidos;

select * from pedidos_detalles where pedido_id = 1;

select sum(total) as total_pedidos from pedidos where cliente_id = 1;

select count(*) as total_clientes from clientes;

select * from pedidos where estado = 'Pendiente';

select * from menus where categoria = 'Postre';

select m.categoria, SUM(pd.precio * pd.cantidad) as total_ventas
from pedidos_detalles pd
    join menus m on pd.menu_id = m.id
group by
    m.categoria;

update pedidos set estado = 'Entregado' where id = 1;