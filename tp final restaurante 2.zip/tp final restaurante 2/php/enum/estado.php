<?php
enum Dia{
    case PREPARACION;
    case PENDIENTE;
    case ENTREGADO;
    
   
}
?>