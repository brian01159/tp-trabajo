<?php
enum Menu: int {
    case uno = 1;
    case Dos = 2;
    case Tres = 3;
    case Cuatro = 4;
    case cinco = 5;
    case seis = 6;
    case siete = 7;
    case ocho = 8;
    case nueve = 9;
    case diez = 10;
}
?>