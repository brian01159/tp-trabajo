<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
//$registros = $connector->getAll("alumnos");
$buscar="";
if(isset($_REQUEST['buscar'])) $buscar=$_REQUEST['buscar'];
$registros = $connector->get("pedidos","estado like '%".$buscar."%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['cliente_id'] . "</td>");
    echo ("<td>" . $registro['total'] . "</td>");
    echo ("<td>" . $registro['estado'] . "</td>");
    echo ("</tr>");
}
?>