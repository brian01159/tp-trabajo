<?php
include_once "php/enum/estado.php";
foreach (Estado::cases() as $estado) {
    echo "<option value='" . $estado->name . "'>" .
        mb_convert_case($estado->name, MB_CASE_LOWER, "UTF-8"). 
         "</option><br>";
}