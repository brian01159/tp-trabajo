<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['menu_id']) && $_REQUEST['menu_id'] != '' &&
    isset($_REQUEST['pedido_id']) && $_REQUEST['pedido_id'] != ''
) {
    $pedido_id = $_REQUEST['pedido_id'];
    $menu_id = $_REQUEST['menu_id'];
    $cantidad = $_REQUEST['cantidad'];
    $precio = $_REQUEST['precio'];

    $tabla = "pedidos_detalles";
    $campos = "pedido_id,menu_id,cantidad,precio";
    $values = "'" . $pedido_id . "','" . $menu_id . "','" . $cantidad . "','" . $precio . "'";
    $connector = new Connector();
    $connector->insert($tabla, $campos, $values);
    echo 'Se ingreso detalle de pedido!';
} else {
    echo 'Ingrese detalle de pedido!';
}
?>