<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
//$registros = $connector->getAll("alumnos");
$buscar="";
if(isset($_REQUEST['buscar'])) $buscar=$_REQUEST['buscar'];
$registros = $connector->get("pedidos_detalles","pedido_id like '%".$buscar."%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['pedido_id'] . "</td>");
    echo ("<td>" . $registro['menu_id'] . "</td>");
    echo ("<td>" . $registro['cantidad'] . "</td>");
    echo ("<td>" . $registro['precio'] . "</td>");
    echo ("</tr>");
}
?>