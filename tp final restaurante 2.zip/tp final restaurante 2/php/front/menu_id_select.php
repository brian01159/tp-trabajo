<?php
include_once "php/enum/menus.php";
foreach (Menu::cases() as $menu_id) {
    echo "<option value='" . $menu_id->value . "'>" .
        mb_convert_case($menu_id->value, MB_CASE_LOWER, "UTF-8") .
        "</option><br>";
}