<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['nombre']) && $_REQUEST['nombre'] != '' &&
    isset($_REQUEST['email']) && $_REQUEST['email'] != ''
) {
    $nombre = $_REQUEST['nombre'];
    $email = $_REQUEST['email'];
    $telefono = $_REQUEST['telefono'];
    $direccion = $_REQUEST['direccion'];

    $tabla = "clientes";
    $campos = "nombre,email,telefono,direccion";
    $values = "'" . $nombre . "','" . $email . "','" . $telefono . "','" . $direccion . "'";
    $connector = new Connector();
    $connector->insert($tabla, $campos, $values);
    echo 'Se ingreso un nuevo cliente!';
} else {
    echo 'Ingrese un nuevo cliente!';
}
?>