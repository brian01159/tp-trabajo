<?php ini_set("display_errors", "1"); ?>
<?php
include_once 'php/connectors/connector.php';
if (
    isset($_REQUEST['cliente_id']) && $_REQUEST['cliente_id'] != '' &&
    isset($_REQUEST['total']) && $_REQUEST['total'] != ''
) {
    $cliente_id= $_REQUEST['cliente_id'];
    $total = $_REQUEST['total'];
    $estado= $_REQUEST['estado'];

    $tabla = "pedidos";
    $campos = "cliente_id,total,estado";
    $values = "'" . $cliente_id ."','" . $total . "','" . $estado. "'";
    $connector=new Connector();
    $connector->insert($tabla,$campos,$values);
    echo 'Se ingreso un nuevo pedido!';
} else {
    echo 'Ingrese un nuevo pedido!';
}
?>