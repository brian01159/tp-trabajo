<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
$buscar = "";
if (isset($_REQUEST['buscar']))
    $buscar = $_REQUEST['buscar'];
$registros = $connector->get("menus", "nombre like '%" . $buscar . "%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['nombre'] . "</td>");
    echo ("<td>" . $registro['precio'] . "</td>");
    echo ("<td>" . $registro['categoria'] . "</td>");
    echo ("</tr>");
}
?>