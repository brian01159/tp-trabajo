<?php
include_once "php/connectors/connector.php";
$connector = new Connector();
//$registros = $connector->getAll("alumnos");
$buscar="";
if(isset($_REQUEST['buscar'])) $buscar=$_REQUEST['buscar'];
$registros = $connector->get("clientes","nombre like '%".$buscar."%'");
foreach ($registros as $registro) {
    echo ("<tr>");
    echo ("<td>" . $registro['id'] . "</td>");
    echo ("<td>" . $registro['nombre'] . "</td>");
    echo ("<td>" . $registro['email'] . "</td>");
    echo ("<td>" . $registro['telefono'] . "</td>");
    echo ("<td>" . $registro['direccion'] . "</td>");
    echo ("</tr>");
}
?>