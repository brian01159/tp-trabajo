<?php ini_set("display_errors", "1"); ?>
<?php
//http://localhost/objetos/tp final restaurante 2/php/test/test_connector.php
include_once '../connectors/connector.php';

echo '-- Inicio de Test Connector --<br>';
$sql = "select version()";

$connector = new Connector();

try {
    $registros = $connector->getConnection()->query($sql);
    echo 'Conexión exitosa!<br>';
    foreach ($registros as $row) {
        echo 'Se conectó a ' . $row[0] . '<br>';
    }
} catch (Exception $e) {
    echo 'Error de conexión!<br>';
    echo $e . '<br>';
}
echo '-- Fin de Test Connector --<br>';

$connector->insert(
    "clientes",
    "nombre,email,telefono,direccion",
    "'rodriguez','robert@gmail.com',11874629,'jose paz 958'"
);

$connector->delete("clientes", "id=3");

$connector->update("clientes", "nombre='Rivas'", "id=5");

echo '-- Inicio Test .get() --<br>';

$registros = $connector->get("clientes", "nombre LIKE '%s'");

foreach ($registros as $row) {
    echo $row['nombre'] . ", " . $row['email'] . ", " . $row['telefono'] . ", " .
        $row['direccion'] . "<br>";
}
echo '-- Fin Test .get() --<br>';

echo '-- Inicio Test .getAll() --<br>';
$registros = $connector->getAll("clientes");
foreach ($registros as $row) {
    echo $row['nombre'] . ", " . $row['email'] . ", " . $row['telefono'] . ", " .
        $row['direccion'] . "<br>";
}
echo '-- Fin Test .getAll() --<br>';
?>