<?php ini_set("display_errors", "1"); ?>
<?php
//http://localhost/objetos/tp final restaurante 2/php/test/test.php
echo "Versión PHP: " . phpversion() . "<br>";
echo phpinfo() . '<br>';
?>