<?php
class Connector {


    public function getConnection() {
        $driver = 'mysql';
        $hostname = '127.0.0.1';
        $username = 'root';
        $password = '';
        $base = 'restaurante';
        
        return new PDO(
            "$driver:host=$hostname;dbname=$base",
            $username,
            $password
        );
    }
    public function getData(){
        
        return "MariaDb 10";
        
    }
    public function insert ($tabla, $campos, $values){
        $sql="insert into $tabla ($campos) values ($values)";
        return $this->getConnection()->exec($sql);
    }

    public function delete ($tabla, $filtro){
        $sql="update $tabla set activo=false where $filtro";
        return $this->getConnection()->exec($sql);
    }

    public function update($tabla, $set, $filtro){
        $sql="update $tabla set $set where $filtro";
        return $this->getConnection()->exec($sql);
    }

    public function get($tabla, $filtro){
        $sql = "select * from $tabla where $filtro and activo=true";
        return $this->getConnection()->query($sql);
    }

    public function getAll($tabla){
        return $this->get($tabla,"1=1");
    }
}
?>
