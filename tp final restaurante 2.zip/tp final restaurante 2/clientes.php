<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mantenimiento de Clientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #ffffff;
            background-color: #6c757d;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            font-weight: bold;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #198754;
            font-weight: bold;
            margin-top: 30px;
        }
        .form-label {
            color: #007bff;
            font-weight: 500;
        }
        .form-control {
            border-radius: 5px;
            box-shadow: inset 0px 1px 3px rgba(0, 0, 0, 0.1);
        }
        .btn-success, .btn-danger {
            font-weight: bold;
            border-radius: 5px;
        }
        .table {
            margin-top: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.05);
        }
        th {
            background-color: #198754;
            color: #ffffff;
            font-weight: bold;
            text-align: center;
        }
        .table-hover tbody tr:hover {
            background-color: #e9f6ec;
            cursor: pointer;
        }
        .category-section {
            margin-top: 30px;
        }
    </style>
</head>
<body>
    <!-- Menú de navegación -->
    <?php include_once "menu.php"; ?>

    <div class="container my-5">
        <!-- Título principal -->
        <h1>Mantenimiento de Clientes</h1>

        <!-- Formulario de Clientes -->
        <form class="p-4">
            <div class="category-section">
                <!-- Nombre -->
                <h2>Nombre</h2>
                <div class="mb-3 row">
                    <label for="nombre" class="col-sm-3 col-form-label form-label">Nombre</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="nombre" name="nombre" required>
                    </div>
                </div>

                <!-- Email -->
                <h2>Email</h2>
                <div class="mb-3 row">
                    <label for="email" class="col-sm-3 col-form-label form-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                </div>

                <!-- Teléfono -->
                <h2>Teléfono</h2>
                <div class="mb-3 row">
                    <label for="telefono" class="col-sm-3 col-form-label form-label">Teléfono</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="telefono" name="telefono" required>
                    </div>
                </div>

                <!-- Dirección -->
                <h2>Dirección</h2>
                <div class="mb-3 row">
                    <label for="direccion" class="col-sm-3 col-form-label form-label">Dirección</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="direccion" name="direccion" required>
                    </div>
                </div>

                <!-- Botones -->
                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-success m-2 col-sm-4">Guardar</button>
                    <button type="reset" class="btn btn-danger m-2 col-sm-4">Borrar</button>
                </div>

                <!-- Información -->
                <div class="mt-3">
                    <label for="info" class="form-label">Información</label>
                    <div class="form-control" id="info">
                        <?php include_once "php/front/agregarClientes.php"; ?>
                    </div>
                </div>
            </div>
        </form>

        <!-- Tabla de Clientes -->
        <div class="category-section">
            <h2>Clientes Registrados</h2>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Email</th>
                        <th scope="col">Teléfono</th>
                        <th scope="col">Dirección</th>
                    </tr>
                </thead>
                <tbody>
                    <?php include_once "php/front/clientesTable.php"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>



