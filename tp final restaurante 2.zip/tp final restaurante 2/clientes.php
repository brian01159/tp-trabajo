<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mantenimiento de Clientes</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
   <link rel="stylesheet" href="css/estilos.css">
</head>

<body>

    <?php include_once "menu.php"; ?>

    <div class="container my-5">
        <h1>Mantenimiento de Clientes</h1>

        <form class="p-4">
            <div class="category-section">
                <h2>Nombre</h2>
                <div class="mb-3 row">
                    <label for="nombre" class="col-sm-3 col-form-label form-label">Nombre</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="nombre" name="nombre" required>
                    </div>
                </div>

                <h2>Email</h2>
                <div class="mb-3 row">
                    <label for="email" class="col-sm-3 col-form-label form-label">Email</label>
                    <div class="col-sm-9">
                        <input type="email" class="form-control" id="email" name="email" required>
                    </div>
                </div>

                <h2>Teléfono</h2>
                <div class="mb-3 row">
                    <label for="telefono" class="col-sm-3 col-form-label form-label">Teléfono</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="telefono" name="telefono" required>
                    </div>
                </div>

                <h2>Dirección</h2>
                <div class="mb-3 row">
                    <label for="direccion" class="col-sm-3 col-form-label form-label">Dirección</label>
                    <div class="col-sm-9">
                        <input type="text" class="form-control" id="direccion" name="direccion" required>
                    </div>
                </div>

                <div class="d-flex justify-content-center">
                    <button type="submit" class="btn btn-success m-2 col-sm-4">Guardar</button>
                    <button type="reset" class="btn btn-danger m-2 col-sm-4">Borrar</button>
                </div>

                <div class="mt-3">
                    <label for="info" class="form-label">Información</label>
                    <div class="form-control" id="info">
                        <?php include_once "php/front/agregar_clientes.php"; ?>
                    </div>
                </div>
            </div>
        </form>

        <div class="category-section">
            <h2>Clientes Registrados</h2>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Email</th>
                        <th scope="col">Teléfono</th>
                        <th scope="col">Dirección</th>
                    </tr>
                </thead>
                <tbody>
                    <?php include_once "php/front/clientes_table.php"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>
