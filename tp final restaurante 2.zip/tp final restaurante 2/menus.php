<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Alimentos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }
        .container {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }
        h1 {
            color: #ffffff;
            background-color: #6c757d;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            font-weight: bold;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }
        h2 {
            color: #198754;
            font-weight: bold;
            margin-top: 30px;
        }
        .list-group-item {
            background-color: #ffffff;
            transition: all 0.3s ease;
            border: none;
            border-bottom: 1px solid #eee;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.05);
            border-radius: 5px;
        }
        .list-group-item:hover {
            background-color: #e9f6ec;
            transform: scale(1.02);
        }
        .badge {
            background-color: #198754;
            font-size: 1rem;
            font-weight: 500;
        }
    </style>
</head>
<body>
    <!-- Menú de navegación -->
    <?php include_once "menu.php"; ?>

    <div class="container my-5">
        <!-- Título principal -->
        <h1>Menú de Alimentos</h1>

        <!-- Entrantes -->
        <div class="category-section">
            <h2>Entrantes</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Ensalada César
                    <span class="badge">$2550.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Sopa de Lentejas
                    <span class="badge">$1800.00</span>
                </li>
            </ul>
        </div>

        <!-- Platos Principales -->
        <div class="category-section">
            <h2>Platos Principales</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Pizza Margarita
                    <span class="badge">$3600.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Hamburguesa Clásica
                    <span class="badge">$3000.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Pasta al Pesto
                    <span class="badge">$3300.00</span>
                </li>
            </ul>
        </div>

        <!-- Postres -->
        <div class="category-section">
            <h2>Postres</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Tiramisú
                    <span class="badge">$1650.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Brownie
                    <span class="badge">$1350.00</span>
                </li>
            </ul>
        </div>

        <!-- Bebidas -->
        <div class="category-section">
            <h2>Bebidas</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Coca-Cola
                    <span class="badge">$600.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Agua Mineral
                    <span class="badge">$450.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Batido de Frutas
                    <span class="badge">$1050.00</span>
                </li>
            </ul>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
