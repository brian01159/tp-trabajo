<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Menú de Alimentos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/estilos1.css">
</head>

<body>
    <?php include_once "menu.php"; ?>

    <div class="container my-5">
        <h1>Menú de Alimentos</h1>

        <div class="category-section">
            <h2>Entrantes</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Ensalada César
                    <span class="badge">$2550.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Sopa de Lentejas
                    <span class="badge">$1800.00</span>
                </li>
            </ul>
        </div>

        <div class="category-section">
            <h2>Platos Principales</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Pizza Margarita
                    <span class="badge">$3600.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Hamburguesa Clásica
                    <span class="badge">$3000.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Pasta al Pesto
                    <span class="badge">$3300.00</span>
                </li>
            </ul>
        </div>

        <div class="category-section">
            <h2>Postres</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Tiramisú
                    <span class="badge">$1650.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Brownie
                    <span class="badge">$1350.00</span>
                </li>
            </ul>
        </div>

        <div class="category-section">
            <h2>Bebidas</h2>
            <ul class="list-group">
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Coca-Cola
                    <span class="badge">$600.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Agua Mineral
                    <span class="badge">$450.00</span>
                </li>
                <li class="list-group-item d-flex justify-content-between align-items-center">
                    Batido de Frutas
                    <span class="badge">$1050.00</span>
                </li>
            </ul>
        </div>

        <div class="category-section">
            <h2>Menus Registrados</h2>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">Id</th>
                        <th scope="col">Nombre</th>
                        <th scope="col">Precio</th>
                        <th scope="col">Categoria</th>
                    </tr>
                </thead>
                <tbody>
                    <?php include_once "php/front/menus_table.php"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>
