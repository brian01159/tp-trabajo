<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mantenimiento de Pedidos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <style>
        body {
            background-color: #f4f6f9;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        .container {
            background: #ffffff;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0px 4px 15px rgba(0, 0, 0, 0.1);
        }

        h1 {
            color: #ffffff;
            background-color: #6c757d;
            padding: 15px;
            border-radius: 10px;
            text-align: center;
            font-weight: bold;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.1);
        }

        h2 {
            color: #198754;
            font-weight: bold;
            margin-top: 30px;
        }

        .form-label {
            color: #007bff;
            font-weight: 500;
        }

        .form-control {
            border-radius: 5px;
            box-shadow: inset 0px 1px 3px rgba(0, 0, 0, 0.1);
        }

        .btn-success,
        .btn-danger {
            font-weight: bold;
            border-radius: 5px;
        }

        table {
            margin-top: 20px;
            box-shadow: 0px 4px 10px rgba(0, 0, 0, 0.05);
        }

        th {
            background-color: #198754;
            color: #ffffff;
            font-weight: bold;
            text-align: center;
        }

        .table-hover tbody tr:hover {
            background-color: #e9f6ec;
            cursor: pointer;
        }

        .category-section {
            margin-top: 30px;
        }
    </style>
</head>

<body>

    <!-- Menú de navegación -->
    <?php include_once "menu.php"; ?>

    <div class="container my-5">
        <!-- Título principal -->
        <h1>Mantenimiento de Pedidos</h1>

        <!-- Formulario de Pedidos -->
        <form class="p-4">
            <!-- Cliente ID -->
            <div class="mb-3 row">
                <label for="cliente_id" class="col-sm-3 col-form-label form-label">Cliente ID</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="cliente_id" name="cliente_id" required>
                </div>
            </div>

            <!-- Total -->
            <div class="mb-3 row">
                <label for="total" class="col-sm-3 col-form-label form-label">Total</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="total" name="total" required>
                </div>
            </div>

            <!-- Estado -->

            <div class="mb-3 row">
                <label for="estado" class="col-sm-3 col-form-label form-label">estado</label>
                <div class="col-sm-9">
                    <select id="estado" name="estado" class="form-select form-label"
                        aria-label="Default select example">
                        <?php include_once "php/front/estadoSelect.php"; ?>
                    </select>
                </div>
            </div>

            <!-- Botones -->
            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-success m-2 col-sm-4">Guardar</button>
                <button type="reset" class="btn btn-danger m-2 col-sm-4">Borrar</button>
            </div>

            <!-- Información -->
            <div class="mt-3">
                <label for="info" class="form-label">Información</label>
                <div class="form-control" id="info">
                    <?php include_once "php/front/agregarPedidos.php"; ?>
                </div>
            </div>
        </form>

        <!-- Tabla de Pedidos -->
        <div class="category-section">
            <h2>Listado de Pedidos</h2>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Cliente ID</th>
                        <th scope="col">Total</th>
                        <th scope="col">Estado</th>
                    </tr>
                </thead>
                <tbody>
                    <?php include_once "php/front/pedidosTable.php"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
</body>

</html>