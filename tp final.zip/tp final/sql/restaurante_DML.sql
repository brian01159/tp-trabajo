
insert into Menu (nombre, precio, categoria) values
('Ensalada César', 2550.00, 'Entrante'),  
('Pizza Margarita', 3600.00, 'Principal'), 
('Tiramisú', 1650.00, 'Postre'),          
('Coca-Cola', 600.00, 'Bebida'),           
('Sopa de Lentejas', 1800.00, 'Entrante'), 
('Hamburguesa Clásica', 3000.00, 'Principal'), 
('Brownie', 1350.00, 'Postre'),            
('Agua Mineral', 450.00, 'Bebida'),        
('Pasta al Pesto', 3300.00, 'Principal'),  
('Batido de Frutas', 1050.00, 'Bebida');   


insert into Clientes (nombre, email, telefono, direccion) values
('Juan Pérez', 'juan.perez@example.com', '123456789', 'Calle Falsa 123'),
('María López', 'maria.lopez@example.com', '987654321', 'Avenida Siempre Viva 742'),
('Carlos Gómez', 'carlos.gomez@example.com', '456123789', 'Calle Verdadera 456'),
('Ana Torres', 'ana.torres@example.com', '321654987', 'Paseo del Prado 789'),
('Lucía Martínez', 'lucia.martinez@example.com', '789456123', 'Calle de la Paz 101'),
('José Ramírez', 'jose.ramirez@example.com', '159753486', 'Calle Nueva 202'),
('Elena Sánchez', 'elena.sanchez@example.com', '753951852', 'Avenida Libertad 303'),
('Diego Romero', 'diego.romero@example.com', '951753486', 'Calle Principal 404'),
('Patricia Ruiz', 'patricia.ruiz@example.com', '456789123', 'Calle Secundaria 505'),
('Javier Díaz', 'javier.diaz@example.com', '147258369', 'Avenida Central 606');


insert into Pedidos (cliente_id, total, estado) values
(1, 6000.00, 'Pendiente'),  
(2, 4650.00, 'En preparación'), 
(3, 9000.00, 'Entregado'),    
(4, 7500.00, 'Pendiente'),   
(5, 3600.00, 'Entregado'),   
(6, 5550.00, 'En preparación'), 
(7, 6600.00, 'Pendiente'),    
(8, 8100.00, 'Entregado'),     
(9, 4200.00, 'Pendiente'),     
(10, 4950.00, 'En preparación'); 


insert into Pedido_Detalle (pedido_id, menu_id, cantidad, precio) values
(1, 1, 1, 2550.00), 
(1, 2, 1, 3600.00),
(2, 3, 2, 1650.00), 
(2, 4, 1, 600.00), 
(3, 5, 1, 1800.00), 
(3, 6, 2, 3000.00), 
(4, 7, 3, 1350.00), 
(4, 8, 2, 450.00),  
(5, 9, 1, 3300.00),  
(5, 10, 1, 1050.00); 