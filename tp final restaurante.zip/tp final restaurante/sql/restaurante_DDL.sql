-- Active: 1729748087871@@127.0.0.1@3306@restaurante

drop database if exists restaurante;

create database restaurante;
use restaurante;

create table Clientes (
    id int auto_increment primary key,
    nombre varchar(100) not null,
    email varchar(100) unique not null,
    telefono varchar(15),
    direccion varchar(255),
    activo boolean default TRUE
);

create table Menus (
    id int auto_increment primary key,
    nombre varchar(100) not null,
    precio decimal(8, 2) not null,
    categoria enum(
        'Entrante',
        'Principal',
        'Postre',
        'Bebida'
    ) not null,
    activo boolean default TRUE
);

create table Pedidos (
    id int auto_increment primary key,
    cliente_id int,
    fecha datetime default current_timestamp,
    total decimal(8, 2) not null,
    estado enum(
        'Pendiente',
        'En preparación',
        'Entregado'
    ) default 'Pendiente',
    foreign key (cliente_id) references Clientes (id),
    activo boolean default TRUE
);

create table Pedidos_Detalles (
    id int auto_increment primary key,
    pedido_id int,
    menu_id int,
    cantidad int not null,
    precio decimal(8, 2) not null,
    foreign key (pedido_id) references Pedidos (id),
    foreign key (menu_id) references Menus (id),
    activo boolean default TRUE
);