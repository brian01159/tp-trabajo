-- Active: 1729748087871@@127.0.0.1@3306@restaurante
use restaurante;

create database restaurante;

drop database restaurante;

create table Menu (
    id int auto_increment primary key,
    nombre varchar(100) not null,
    precio decimal(8, 2) not null,
    categoria enum(
        'Entrante',
        'Principal',
        'Postre',
        'Bebida'
    ) not null
);

create table Clientes (
    id int auto_increment primary key,
    nombre varchar(100) not null,
    email varchar(100) unique not null,
    telefono varchar(15),
    direccion varchar(255)
);

create table Pedidos (
    id int auto_increment primary key,
    cliente_id int,
    fecha datetime default current_timestamp,
    total decimal(8, 2) not null,
    estado enum(
        'Pendiente',
        'En preparación',
        'Entregado'
    ) default 'Pendiente',
    foreign key (cliente_id) references Clientes (id) on delete cascade
);

create table Pedido_Detalle (
    id int auto_increment primary key,
    pedido_id int,
    menu_id int,
    cantidad int not null,
    precio decimal(8, 2) not null,
    foreign key (pedido_id) references Pedidos (id) on delete cascade,
    foreign key (menu_id) references Menu (id) on delete cascade
);