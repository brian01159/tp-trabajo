-- Active: 1729748087871@@127.0.0.1@3306@restaurante
select * from Menus;

select * from Clientes;

select id, cliente_id, fecha, total, estado from Pedidos;

select * from Pedidos_Detalles where pedido_id = 1;

select sum(total) as total_pedidos from Pedidos where cliente_id = 1;

select count(*) as total_clientes from Clientes;

select * from Pedidos where estado = 'Pendiente';

select * from Menus where categoria = 'Postre';

select m.categoria, SUM(pd.precio * pd.cantidad) as total_ventas
from Pedidos_Detalles pd
    join Menus m on pd.menu_id = m.id
group by
    m.categoria;

update Pedidos set estado = 'Entregado' where id = 1;