<?php
class Connector {
    private $host = '127.0.0.1';
    private $usuario = 'root';
    private $contrasena = 'lolanida123';
    private $base_datos = 'restaurante';
    private $conexion;

    
    public function __construct() {
        $this->conexion = new mysqli($this->host, $this->usuario, $this->contrasena, $this->base_datos);

        if ($this->conexion->connect_error) {
            die('Error de conexión: ' . $this->conexion->connect_error);
        } else {
            echo 'Conexión exitosa.<br>';
        }
    }

    private function getConnection() {
        return $this->conexion;
    }

    
    public function query($sql) {
        return $this->getConnection()->query($sql);
    }


    public function insert($tabla, $campos, $values) {
        $sql = "INSERT INTO $tabla ($campos) VALUES ($values)";
        return $this->query($sql);
    }

    
    public function delete($tabla, $filtro) {
        $sql = "DELETE FROM $tabla WHERE $filtro";
        return $this->query($sql);
    }


    public function update($tabla, $set, $filtro) {
        $sql = "UPDATE $tabla SET $set WHERE $filtro";
        return $this->query($sql);
    }


    public function get($tabla, $filtro) {
        $sql = "SELECT * FROM $tabla WHERE $filtro";
        return $this->query($sql);
    }


    public function getAll($tabla) {
        return $this->get($tabla, "1=1");
    }
}
?>
