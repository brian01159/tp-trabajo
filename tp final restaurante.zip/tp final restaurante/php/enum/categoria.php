<?php
enum Categoria{
    case entrante;
    case principal;
    case postre;
    case bebida;
}
?>