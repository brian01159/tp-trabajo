<?php
enum Estado{
    case pendiente;
    case preparacion;
    case entregado;

}
?>