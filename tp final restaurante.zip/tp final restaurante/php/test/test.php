<?php ini_set("display_errors", "1"); ?>
<?php
//http://localhost/objetos/tp final restaurante/php/test/test.php
echo "Versión PHP: " . phpversion() . "<br>";
echo phpinfo() . '<br>';
?>