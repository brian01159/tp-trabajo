<?php
require_once "../entities/radio.php";

abstract class Vehiculo
{
    private $marca;
    private $color;
    private $modelo;
    private $precio;
    private $radio;


    public function __construct(string $marca, string $color,string $modelo,float  $precio = null,string $radio = null)
    {
        $this->marca = $marca;
        $this->color = $color;
        $this->modelo = $modelo;
        $this->precio = $precio;
        $this->radio = $radio;


    }

    public function cambiarRadio( Radio $radio)
    {
        $this->radio = $radio;
        return "Estos son los datos de la radio cambiada:" . "<br>" .

            "esta es su marca cambiada:" . $this->radio->__get("marca") . "<br>" .
            "esta es su potencia cambiada:" . $this->radio->__get("potencia") . "<br>";

    }
    public function AgregarRadio(Radio $radio)
    {
        $this->radio = $radio;
        return "Estos son los datos de la radio agregada:" . "<br>" .
            "esta es su Marca: " . $this->radio->__get("marca") . "<br>" .
            "esta es su potencia: " . $this->radio->__get("potencia") . "<br>";
    }

    public function __tostring(): string
    {
        return "estos son datos del vehiculo" . $this->marca . "," . $this->color . "," . $this->modelo . "," . $this->precio . "," . $this->radio;
    }


    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }

    }


    public function __set($property, $value)
    {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
    }


}




?>