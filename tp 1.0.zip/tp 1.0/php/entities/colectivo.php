<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
final class Colectivo extends Vehiculo
{
    private $radio;

    public function __construct(string $marca, string $color, string $modelo, float $precio)
    {
        parent::__construct($marca, $color, $modelo, $precio);
        $this->radio =new Radio("philips",1000);
    }

    public function __tostring(): string
    {
        $radioMarca = $this->radio->__get("marca") . "<br>";
        $radioPotencia = $this->radio->__get("potencia") . "<br>";

        return "este son los detalles del colectivo  " . "<br>" .
            "Marca: " . $this->__get("marca") . "<br>" .
            "Color: " . $this->__get("color") . "<br> " .
            "Modelo: " . $this->__get("modelo") . "<br>" .
            "Precio: " . $this->__get("precio") . "<br> " .
            "Marca de la radio: " . $radioMarca . "<br>" .
            "Potencia de la radio: " . $radioPotencia . "<br>";
    }

}






?>