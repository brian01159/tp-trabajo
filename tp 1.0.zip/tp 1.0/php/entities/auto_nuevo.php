<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
class AutoNuevo extends Vehiculo
{
    private $radio;



    public function __construct(string $marca, string $color, string $modelo, float $precio)
    {
        parent::__construct($marca, $color, $modelo, $precio);
        $this->radio=new Radio("sony",1700);

    }


    public function __tostring(): string
    {

        return "esto son los detalles del auto nuevo con su radio:" ."<br>".
            "este es su marca:" . $this->__get("marca") . "<br>" .
            "este es su color:" . $this->__get("color") . "<br>" .
            "este es su modelo:" . $this->__get("modelo") . "<br>" .
            "este es su precio:" . $this->__get("precio") . "<br>" .
            "esta es Marca de la radio: " . $this->radio->__get("marca") . "<br>" .
            "esta es la Potencia de la radio: " . $this->radio->__get("potencia") . "<br>";
    }
    
}
?>