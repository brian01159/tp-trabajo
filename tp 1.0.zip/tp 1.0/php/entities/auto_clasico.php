<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
class AutoClasico extends Vehiculo
{
    private $radio;

    public function __construct(string $marca, string $color, string $modelo, float $precio)
    {
        parent::__construct($marca, $color, $modelo, $precio);
        $this->radio= new Radio("philips",200); 
    }


    public function __tostring(): string
    {
        $radioMarca = $this->radio->__get("marca") . "<br>";
        $radioPotencia = $this->radio->__get("potencia") . "<br>";
        return "esto son los detalles del auto clasico:" . "<br>" .
            "este es su marca:" . $this->__get("marca") . "<br>" .
            "este es su color:" . $this->__get("color") . "<br>" .
            "este es su modelo:" . $this->__get("modelo") . "<br>" .
            "este es su precio:" . $this->__get("precio") . "<br>" .
            "este es su marca de la radio:" . $radioMarca . "<br>" .
            "este es la potencia de la radio:" . $radioPotencia . "<br>";

    }

 



}
?>