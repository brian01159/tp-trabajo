<?php ini_set('display_errors', 1) ?>
<?php
//http://localhost/objetos/TP 1.0/php/test/test_vehiculo.php
require_once "../entities/auto_nuevo.php";
require_once "../entities/radio.php";
require_once "../entities/colectivo.php";
require_once "../entities/auto_clasico.php";


echo "<h1>Test Vehiculo</h1>";
echo "<h3> Test Auto Nuevo </h3><br>";
echo "<h3> Auto Nuevo 1 </h3><br>";



$autonuevo1 = new AutoNuevo("Toyota", "Negro", "Corolla", "500000");
echo $autonuevo1;
$radio2 = new Radio("sony", 1500);
echo $autonuevo1->CambiarRadio($radio2);




echo "<h3> Test Colectivo </h3><br>";
echo "<h3> Colectivo 1 </h3><br>";



$colectivo1 = new Colectivo("chrysler", "rojo", "cry", "300000");
echo $colectivo1;
$radio11=new radio("sony",700);
echo $colectivo1->AgregarRadio($radio11);

$radio4 = new Radio("philips", 1000);
echo $colectivo1->cambiarRadio($radio4) . "<br>";



echo "<h3>Test Auto Clasico </h3><br>";
echo "<h3>Auto Clasico 1 </h3><br>";


$autoclasico1 = new AutoClasico("chevrolet", "rojo", "onix", "250000");
echo $autoclasico1;
$radio7=new Radio("sony",2000);
echo $autoclasico1->AgregarRadio($radio7) . "<br>";
$radio3 = new Radio("philips", 300);
echo $autoclasico1->cambiarRadio($radio3) . "<br>";






?>