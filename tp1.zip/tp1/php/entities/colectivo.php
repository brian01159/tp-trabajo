<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
final class Colectivo extends Vehiculo
{
    public function __construct($color, $marca, $modelo, $precio)
    {
        parent::__construct($marca, $color, $modelo, $precio);

    }



}






?>