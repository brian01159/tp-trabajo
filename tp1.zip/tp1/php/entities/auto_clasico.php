<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
class AutoClasico extends Vehiculo
{


    public function __construct($color, $marca, $modelo, $precio)
    {
        parent::__construct($marca, $color, $modelo, $precio);


    }

 
}
?>