<?php
require_once "../entities/radio.php";

abstract class Vehiculo
{
    private $marca;
    private $color;
    private $modelo;
    private $precio;
    private $radio;


    public function __construct(
        string $marca,
        string $color,
        string $modelo,
        float $precio = null,
        radio $radio = null
    ) {
        $this->marca = $marca;
        $this->color = $color;
        $this->modelo = $modelo;
        $this->precio = $precio;
        $this->radio = $radio;


    }
    public function cambiarRadio(string $marca, float $potencia)
    {
        $this->radio = new radio($marca, $potencia);
    }



    public function agregarRadio(string $marca, float $potencia)
    {

        $this->radio = new radio($marca, $potencia);
    }


    public function __tostring(): string
    {
        return "estos son datos del vehiculo" . $this->marca . "," . $this->color . "," . $this->modelo . "," . $this->precio . "," . $this->radio;
    }


    public function __get($property)
    {
        if (property_exists($this, $property)) {
            return $this->$property;
        }

    }


    public function __set($property, $value)
    {
        if (property_exists($this, $property)) {
            $this->$property = $value;
        }
    }


}




?>