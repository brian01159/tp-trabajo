<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
class AutoNuevo extends Vehiculo
{




    public function __construct($color, $marca, $modelo, $precio)
    {
        parent::__construct($marca, $color, $modelo, $precio);

        $this->agregarRadio("sony", 1200);

    }

}
?>