<?php ini_set('display_errors', 1) ?>
<?php
//http://localhost/objetos/TP1/php/test/test_vehiculo.php
require_once "../entities/auto_nuevo.php";
require_once "../entities/radio.php";
require_once "../entities/colectivo.php";
require_once "../entities/auto_clasico.php";


echo "<h1>Test Vehiculo</h1>";
echo "<h3> Test Auto Nuevo </h3><br>";
echo "<h3> Auto Nuevo 1 </h3><br>";



$autonuevo1 = new AutoNuevo(
    "Toyota",
    "Negro",
    "Corolla",
    "500000"

);
echo $autonuevo1 . "<br>";
echo $autonuevo1->cambiarRadio("sony", 1500);
echo $autonuevo1;




echo "<h3> Test Colectivo </h3><br>";
echo "<h3> Colectivo 1 </h3><br>";



$colectivo1 = new Colectivo("chrysler", "rojo", "cry", "300000");
$colectivo1->AgregarRadio("sony", 700);
echo $colectivo1;
echo $colectivo1->cambiarRadio("philips", 1000) . "<br>";
echo $colectivo1;


echo "<h3>Test Auto Clasico </h3><br>";
echo "<h3>Auto Clasico 1 </h3><br>";


$autoclasico1 = new AutoClasico("chevrolet", "rojo", "onix", "250000");
echo $autoclasico1->AgregarRadio("sony", 2000) . "<br>";
echo $autoclasico1;
echo $autoclasico1->cambiarRadio("philips", 300) . "<br>";
echo $autoclasico1;





?>