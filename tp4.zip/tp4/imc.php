<!DOCTYPE html>
<html lang="es">
<!-- http://localhost/objetos/TP4/imc.php -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Calculadora de IMC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body class="bg-light">
    <div class="container mt-5">
        <h1 class="text-center text-primary">Calculadora de IMC</h1>
        <div class="row justify-content-center">
            <div class="col-md-6">
                <form id="formIMC">
                    <div class="mb-3">
                        <label for="peso" class="form-label">Peso (kg)</label>
                        <input type="number" id="peso" class="form-control" placeholder="Ingrese su peso en kg" required>
                    </div>
                    <div class="mb-3">
                        <label for="altura" class="form-label">Altura (cm)</label>
                        <input type="number" id="altura" class="form-control" placeholder="Ingrese su altura en cm" required>
                    </div>
                    <button type="button" onclick="calcularIMC()" class="btn btn-primary w-100">Calcular IMC</button>
                </form>
                <div id="resultado" class="mt-4 text-center fs-5"></div>
            </div>
        </div>
    </div>
    <script src="js/imc.js"></script>
</body>

</html>