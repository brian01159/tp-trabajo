function calcularIMC() {
    const peso = parseFloat(document.getElementById("peso").value);
    const altura = parseFloat(document.getElementById("altura").value) / 100;

    if (!peso || !altura || peso <= 0 || altura <= 0) {
        document.getElementById("resultado").textContent = "Por favor, ingrese valores válidos.";
        return;
    }

    const imc = peso / (altura * altura);
    let estado;


    if (imc < 15.0) {
        estado = "Delgadez muy severa";
    } else if (imc >= 15.0 && imc <= 15.9) {
        estado = "Delgadez severa";
    } else if (imc >= 16.0 && imc <= 18.4) {
        estado = "Delgadez";
    } else if (imc >= 18.5 && imc <= 24.9) {
        estado = "Normal";
    } else if (imc >= 25.0 && imc <= 29.9) {
        estado = "Sobrepeso";
    } else if (imc >= 30.0 && imc <= 34.9) {
        estado = "Obesidad moderada";
    } else if (imc >= 35.0 && imc <= 39.9) {
        estado = "Obesidad severa";
    } else {
        estado = "Obesidad mórbida";
    }


    document.getElementById("resultado").innerHTML = "IMC: " + imc.toFixed(2) + "<br>Estado: " + estado;
}

