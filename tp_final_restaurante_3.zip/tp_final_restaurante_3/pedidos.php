<!DOCTYPE html>
<html lang="es">
<!-- http://localhost/objetos/tp_final_restaurante_3/pedidos.php -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mantenimiento de Pedidos</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
        <link rel="stylesheet" href="css/estilos.css">
</head>

<body>

    <?php include_once "menu.php"; ?>

    <div class="container my-5">
        <h1>Mantenimiento de Pedidos</h1>
        <form class="p-4">
            <div class="mb-3 row">
                <label for="cliente_id" class="col-sm-3 col-form-label form-label">Cliente ID</label>
                <div class="col-sm-9">
                <select id="cliente_id" name="cliente_id" class="form-select form-label"
                        aria-label="Default select example">
                        <?php include_once "php/front/select/clientes_select.php"; ?>
                    </select>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="total" class="col-sm-3 col-form-label form-label">Total</label>
                <div class="col-sm-9">
                    <input type="text" class="form-control" id="total" name="total" required>
                </div>
            </div>

            <div class="mb-3 row">
                <label for="estado" class="col-sm-3 col-form-label form-label">estado</label>
                <div class="col-sm-9">
                    <select id="estado" name="estado" class="form-select form-label"
                        aria-label="Default select example">
                        <?php include_once "php/front/select/estados_select.php"; ?>
                    </select>
                </div>
            </div>

            <div class="d-flex justify-content-center">
                <button type="submit" class="btn btn-success m-2 col-sm-4">Guardar</button>
                <button type="reset" class="btn btn-danger m-2 col-sm-4">Borrar</button>
            </div>


            <div class="mt-3">
                <label for="info" class="form-label">Información</label>
                <div class="form-control" id="info">
                    <?php include_once "php/front/agregar/agregar_pedidos.php"; ?>
                </div>
            </div>
        </form>

        <div class="category-section">
            <h2>Listado de Pedidos</h2>
            <table class="table table-striped table-hover">
                <thead>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">Cliente ID</th>
                        <th scope="col">Total</th>
                        <th scope="col">Estado</th>
                        <th scope="col">Borrar</th>
                    </tr>
                </thead>
                <tbody>
                    <?php include_once "php/front/table/pedidos_table.php"; ?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz"
        crossorigin="anonymous"></script>
        <script src="js/main.js"></script>
</body>

</html>