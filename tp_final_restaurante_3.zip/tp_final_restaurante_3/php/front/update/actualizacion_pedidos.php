<?php
// Incluir el archivo de conexión
include_once '../../connectors/connector.php';

// Crear una instancia de la clase Connector
$connector = new Connector();

$estados_validos = ["En preparación", "Entregado", "Pendiente"];

if (isset($_POST['pedido_id']) && isset($_POST['estado']) && in_array($_POST['estado'], $estados_validos)) {
    $pedido_id = $_POST['pedido_id'];
    $estado = $_POST['estado'];
    
    // Preparar la consulta SQL para actualizar el estado
    $sql = "UPDATE pedidos SET estado = :estado WHERE id = :pedido_id";
    $params = array(':estado' => $estado, ':pedido_id' => $pedido_id);
    
    // Ejecutar la consulta usando el método execute()
    $resultado = $connector->execute($sql, $params);
    
    // Redirigir si la actualización fue exitosa
    if ($resultado) {
        header("Location: ../../../pedidos.php");
        exit();
    } else {
        echo "Error al actualizar el estado.";
    }
} else {
    echo "Datos inválidos.";
}
?>
