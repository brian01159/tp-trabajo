<?php ini_set("display_errors", "1"); ?>
<?php
//http://localhost/objetos/tp final restaurante/php/test/test_connector.php
include_once '../connectors/connector.php';

$connector = new Connector();



?>