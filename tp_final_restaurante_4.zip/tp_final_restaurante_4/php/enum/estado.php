<?php
enum Estado{
    case PENDIENTE;
    case ENTREGADO;
    case PREPARACION;
}
?>