<?php
include_once "php/connectors/connector.php";
$connector=new Connector();
$registros=$connector->getAll("pedidos");
foreach ($registros as $registro) {
    echo "<option value='" . $registro['id'] . "'>" .
            $registro['id'].', '.$registro['cliente_id'].', '.$registro['total']
            .', '.$registro['estado']
        ."</option><br>";
}
?>